#!/usr/bin/python3
print("Content-type: text/plain\n")

#http://tartarus.ccgs.wa.edu.au/~1022309/cgibin/ChatCCGS/unblockUser.py?username=130&password=password123&user=131

import cgi
import cgitb; cgitb.enable()
import sqlite3
import serverTools

#settings

db = "test.db"

#code

form = cgi.FieldStorage()

requiredFields = ["username","password","user"]
inp = {'username':None,'password':None,'user':None}


if not all([x in form for x in requiredFields]):
    print("400 Bad Request")
    exit()

try:
    inp["username"] = int(form["username"].value)
    inp["password"] = form["password"].value
    inp["user"] = int(form["user"].value)
    
except:
    print("422 Unprocessable Entity")
    exit()

#Validate user

if not serverTools.validate(inp["username"],inp["password"]):
    print("401 Unauthorized")
    exit()

if not serverTools.studentExists(inp["user"]):
    print("601 Recipient Not Found")
    exit()

if not serverTools.blockExists(inp["username"],inp["user"]):
    print("607 User Not Blocked")
    exit()

print(serverTools.removeBlock(inp['username'],inp['user']))

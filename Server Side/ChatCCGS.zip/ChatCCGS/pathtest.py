lines = open("../../../Desktop/pathtest.txt").readlines()
print(lines)

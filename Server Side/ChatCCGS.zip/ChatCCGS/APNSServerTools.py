import sqlite3
import datetime

from apns2.client import APNSClient
from apns2.notification import Payload
import apns2

cert = "certificate.pem"

db = "test.db"

client = APNSClient(mode="dev",client_cert=cert,password="***%-+CCGSAPNS091@@ ")

def validate(user,password):
    data = None

    try:
        con = sqlite3.connect(db)
        cur = con.cursor()

        #DB accessing
        t = (user,password)

        cur.execute("SELECT * FROM Students WHERE ID = ? AND password = ?;",t)

        data = cur.fetchall()

        
    except sqlite3.Error:
        print("500 Internal Server Error")
        if con:
            con.rollback()
            con.close()
        print("error in validate")
        exit()
    finally:
        if con:
            con.close()
    
    if data:
        return True
    else:
        return False

def addEntry(user,token,enabled):
    try:
        con = sqlite3.connect(db)
        cur = con.cursor()

        t = (user,token,enabled)

        cur.execute("INSERT INTO APNS(studentID,token,enabled) VALUES (?,?,?);",t)

        con.commit()
    except sqlite3.Error:
        if con:
            con.rollback()
            con.close()
        return "500 Internal Server Error"
    finally:
        if con:
            con.close()
    return "100 Continue"

def getEntryForUser(user):
    data = None

    try:
        con = sqlite3.connect(db)
        cur = con.cursor()

        #DB accessing
        t = (user,)

        cur.execute("SELECT * FROM APNS WHERE studentID = ?;",t)

        data = cur.fetchone()

        
    except sqlite3.Error:
        print("500 Internal Server Error")
        if con:
            con.rollback()
            con.close()
        print("error in getEntryForUser")
        exit()
    finally:
        if con:
            con.close()
    
    return data

def setToken(user,token):
    try:
        con = sqlite3.connect(db)
        cur = con.cursor()

        t = (token,user)

        cur.execute("UPDATE APNS SET token = ? WHERE studentID = ?;",t)

        con.commit()
    except sqlite3.Error:
        if con:
            con.rollback()
            con.close()
        return "500 Internal Server Error"
    finally:
        if con:
            con.close()
    return "100 Continue"
    
def setEnabled(user,enabled):
    try:
        con = sqlite3.connect(db)
        cur = con.cursor()

        t = (enabled,user)

        cur.execute("UPDATE APNS SET enabled = ? WHERE studentID = ?;",t)

        con.commit()
    except sqlite3.Error:
        if con:
            con.rollback()
            con.close()
        return "500 Internal Server Error"
    finally:
        if con:
            con.close()
    return "100 Continue"

def getTokenForUser(user):
    data = None
    
    try:
        con = sqlite3.connect(db)
        cur = con.cursor()

        t = (user,)

        cur.execute("SELECT (token) FROM APNS WHERE studentID=?;",t)
        data=cur.fetchone()

        con.commit()
    except sqlite3.Error:
        if con:
            con.rollback()
            con.close()
        return "500 Internal Server Error"
    finally:
        if con:
            con.close()
    if data:
        return data[0]
    return data

def notificationsEnabled(user):
    data = None
    
    try:
        con = sqlite3.connect(db)
        cur = con.cursor()

        t = (user,)

        cur.execute("SELECT (enabled) FROM APNS WHERE studentID=?;",t)
        data=cur.fetchone()

        con.commit()
    except sqlite3.Error:
        if con:
            con.rollback()
            con.close()
        return "500 Internal Server Error"
    finally:
        if con:
            con.close()
    if data:
        return data[0]
    return data

#alert is apns2.PayloadAlert type
def sendNotification(token, alert, badge=420):
    assert(token != -1)
    assert(type(token) == str)

    global client
    payload = Payload(alert = alert,sound = "default",badge = badge)
    n = apns2.Notification(payload=payload, priority=apns2.PRIORITY_HIGH)
    topic = "au.edu.wa.ccgs.MarcusHandley.NPA.ChatCCGS"
    response = client.push(n=n, device_token=token,topic=topic)
    

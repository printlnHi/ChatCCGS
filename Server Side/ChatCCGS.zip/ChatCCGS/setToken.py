#!/usr/bin/python3
print("Content-type: text/plain\n")

#http://tartarus.ccgs.wa.edu.au/~1022309/cgibin/ChatCCGS/setToken.py?username=123&password=password123&token=testing&enabled=1

import cgi
import cgitb; cgitb.enable()
import sqlite3
import APNSServerTools

#settings

db = "test.db"

#code

form = cgi.FieldStorage()

requiredFields = ["username","password","token","enabled"]
inp = {'username':None,'password':None,'token':None,"enabled":None}


if not all([x in form for x in requiredFields]):
    print("400 Bad Request")
    exit()

try:
    inp["username"] = int(form["username"].value)
    inp["password"] = form["password"].value
    inp["token"] = form["token"].value
    inp["enabled"] = int(form["enabled"].value)
    
except:
    print("422 Unprocessable Entity")
    exit()

#Validate user

if not APNSServerTools.validate(inp["username"],inp["password"]):
    print("401 Unauthorized")
    exit()

err = "500 Internal Server Error"
if APNSServerTools.getEntryForUser(inp["username"]):
    #user has entry already
    if inp["token"] != '-1':
        if APNSServerTools.setToken(inp["username"],inp["token"]) == err:
            print("500 Internal Server Error")
            exit()
    if inp["enabled"] != -1:
        if APNSServerTools.setEnabled(inp["username"],inp["enabled"]) == err:
            print("500 Internal Server Error")
            exit()
    print("100 Continue")
else:
    #user does not have entry
    print(APNSServerTools.addEntry(inp["username"],inp["token"],inp["enabled"]))
